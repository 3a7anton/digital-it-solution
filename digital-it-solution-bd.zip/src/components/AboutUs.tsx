import React from 'react';

const AboutUs: React.FC = () => {
  return (
    <div style={{ 
      color: 'white', 
      padding: '2rem',
      maxWidth: '1200px',
      margin: '0 auto'
    }}>
      <h1 style={{ 
        textAlign: 'center', 
        marginBottom: '2rem',
        fontSize: '2.5rem'
      }}>
        About Us
      </h1>
      
      <section style={{ 
        marginBottom: '3rem' 
      }}>
        <h2 style={{ 
          marginBottom: '1rem',
          fontSize: '1.8rem'
        }}>
          Our Story
        </h2>
        <p style={{ 
          lineHeight: '1.6',
          fontSize: '1.1rem',
          marginBottom: '1.5rem'
        }}>
          Founded in 2024, Digital IT Solutions has quickly established itself as a leading provider 
          of innovative IT services. With a team of dedicated professionals and a passion for technology, 
          we've successfully completed over 50 projects for clients across various industries.
        </p>
        <p style={{ 
          lineHeight: '1.6',
          fontSize: '1.1rem'
        }}>
          Our mission is to empower businesses with cutting-edge technology solutions that drive growth, 
          efficiency, and competitive advantage. We believe in building long-term partnerships with our 
          clients based on trust, quality, and exceptional service.
        </p>
      </section>
      
      <section style={{ 
        marginBottom: '3rem' 
      }}>
        <h2 style={{ 
          marginBottom: '1rem',
          fontSize: '1.8rem'
        }}>
          Our Goals
        </h2>
        <div style={{ 
          display: 'flex',
          flexWrap: 'wrap',
          gap: '1.5rem'
        }}>
          {[1, 2, 3].map((goal) => (
            <div 
              key={goal} 
              style={{ 
                backgroundColor: '#222',
                padding: '1.5rem',
                borderRadius: '8px',
                flex: 1,
                minWidth: '250px'
              }}
            >
              <h3 style={{ 
                marginBottom: '1rem',
                fontSize: '1.3rem'
              }}>
                Goal {goal}
              </h3>
              <p>
                We strive to deliver excellence in every project, continuously innovate our 
                services, and build lasting relationships with our clients.
              </p>
            </div>
          ))}
        </div>
      </section>
      
      <section>
        <h2 style={{ 
          marginBottom: '1rem',
          fontSize: '1.8rem'
        }}>
          Our Achievements
        </h2>
        <div style={{ 
          backgroundColor: '#222',
          padding: '2rem',
          borderRadius: '8px',
          textAlign: 'center'
        }}>
          <h3 style={{ 
            fontSize: '2rem',
            marginBottom: '1rem'
          }}>
            50+ Projects Completed
          </h3>
          <p>
            Since our inception in 2024, we've successfully delivered over 50 projects 
            across various domains, helping businesses achieve their digital transformation goals.
          </p>
        </div>
      </section>
    </div>
  );
};

export default AboutUs;