import React from 'react';

const Services: React.FC = () => {
  const services = [
    {
      id: 1,
      title: "Branding and Printing",
      description: "Professional branding solutions and high-quality printing services to establish your brand identity."
    },
    {
      id: 2,
      title: "Motion Graphics",
      description: "Engaging motion graphics for marketing, presentations, and digital media with optional extras like voice over and models."
    },
    {
      id: 3,
      title: "Website Development",
      description: "Custom website development tailored to your business needs with responsive design and modern technologies."
    },
    {
      id: 4,
      title: "Animation Video",
      description: "Creative animation videos for marketing, education, and entertainment purposes."
    },
    {
      id: 5,
      title: "OVC",
      description: "Complete video production services including models, voice over, scriptwriting, shooting, photography, and video editing."
    },
    {
      id: 6,
      title: "AV Company Portfolio",
      description: "Professional audiovisual portfolio creation to showcase your company's capabilities and achievements."
    },
    {
      id: 7,
      title: "Photography",
      description: "High-quality product photography with optional model services to showcase your products effectively."
    },
    {
      id: 8,
      title: "Videography",
      description: "Professional videography services for events, commercials, documentaries, and promotional content."
    },
    {
      id: 9,
      title: "Software Development",
      description: "Custom software development solutions tailored to your business requirements and industry standards."
    }
  ];

  return (
    <div style={{ 
      color: 'white', 
      padding: '2rem',
      maxWidth: '1200px',
      margin: '0 auto'
    }}>
      <h1 style={{ 
        textAlign: 'center', 
        marginBottom: '2rem',
        fontSize: '2.5rem'
      }}>
        Our Services
      </h1>
      
      <div style={{ 
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
        gap: '2rem'
      }}>
        {services.map((service) => (
          <div 
            key={service.id} 
            style={{ 
              backgroundColor: '#222',
              padding: '1.5rem',
              borderRadius: '8px',
              boxShadow: '0 4px 8px rgba(0,0,0,0.3)',
              transition: 'transform 0.3s ease',
              cursor: 'pointer'
            }}
            onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-5px)'}
            onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
          >
            <h3 style={{ 
              marginBottom: '1rem',
              fontSize: '1.5rem'
            }}>
              {service.title}
            </h3>
            <p style={{ 
              lineHeight: '1.6'
            }}>
              {service.description}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Services;