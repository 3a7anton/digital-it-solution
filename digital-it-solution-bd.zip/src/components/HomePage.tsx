import React from 'react';

const HomePage: React.FC = () => {
  return (
    <div style={{ 
      color: 'white', 
      padding: '2rem',
      maxWidth: '1200px',
      margin: '0 auto'
    }}>
      {/* Hero Section */}
      <section style={{ 
        textAlign: 'center', 
        padding: '4rem 0',
        marginBottom: '3rem'
      }}>
        <h1 style={{ 
          fontSize: '3rem', 
          marginBottom: '1rem' 
        }}>
          Digital IT Solutions
        </h1>
        <p style={{ 
          fontSize: '1.2rem', 
          maxWidth: '800px', 
          margin: '0 auto',
          lineHeight: '1.6'
        }}>
          Your trusted partner for comprehensive IT solutions. We provide cutting-edge services 
          to help your business thrive in the digital world.
        </p>
      </section>

      {/* Partners Section */}
      <section style={{ 
        marginBottom: '3rem' 
      }}>
        <h2 style={{ 
          textAlign: 'center', 
          marginBottom: '2rem',
          fontSize: '2rem'
        }}>
          Our Partners
        </h2>
        <div style={{ 
          display: 'flex', 
          justifyContent: 'center', 
          gap: '2rem',
          flexWrap: 'wrap'
        }}>
          {/* Empty partner slots - to be filled later */}
          {[1, 2, 3, 4].map((item) => (
            <div 
              key={item} 
              style={{ 
                width: '150px', 
                height: '100px', 
                backgroundColor: '#333',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                borderRadius: '8px'
              }}
            >
              <span>Partner {item}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Testimonials Section */}
      <section>
        <h2 style={{ 
          textAlign: 'center', 
          marginBottom: '2rem',
          fontSize: '2rem'
        }}>
          What Our Clients Say
        </h2>
        <div style={{ 
          display: 'flex', 
          justifyContent: 'center', 
          gap: '2rem',
          flexWrap: 'wrap'
        }}>
          {[1, 2].map((item) => (
            <div 
              key={item} 
              style={{ 
                backgroundColor: '#222',
                padding: '1.5rem',
                borderRadius: '8px',
                maxWidth: '400px',
                textAlign: 'center'
              }}
            >
              <p style={{ 
                fontStyle: 'italic',
                marginBottom: '1rem'
              }}>
                "Digital IT Solutions transformed our business with their exceptional service 
                and technical expertise. Highly recommended!"
              </p>
              <p style={{ fontWeight: 'bold' }}>
                - Client {item}
              </p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default HomePage;